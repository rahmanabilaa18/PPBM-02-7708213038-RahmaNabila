package com.example.bismillahbisa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class list_data  {

    String name, time;
    int image;

    public list_data(String name,String time, int image) {
        this.name = name;
        this.time = time;
        this.image = image;



        }

    }
